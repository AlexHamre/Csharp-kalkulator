﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Kalkulator
{
    public partial class kalkulator : Form
    {
        public kalkulator()
        {
            InitializeComponent();
        }
        // op is the operator, tall1 is the first opperand, lblAnswer will be used as the second operand
        public static string op = "";
        public static float tall1 = 0;

        // function to add a number to the lblAnswer.Text string at the end. And scale the font if necessary
        public void addnumber(string input)
        {
            lblAnswer.Text += input;

            // https://stackoverflow.com/questions/9527721/resize-text-size-of-a-label-when-the-text-gets-longer-than-the-label-size
            while (lblAnswer.Width < System.Windows.Forms.TextRenderer.MeasureText(lblAnswer.Text,
            new Font(lblAnswer.Font.FontFamily, lblAnswer.Font.Size, lblAnswer.Font.Style)).Width)
            {
                lblAnswer.Font = new Font(lblAnswer.Font.FontFamily, lblAnswer.Font.Size - 0.5f, lblAnswer.Font.Style);
            }

        }
        // empties lbl.Text and tall1
        private void btnClear_Click(object sender, EventArgs e)
        {
            lblAnswer.Text = "";
            tall1 = 0;
        }
        // the next 10 functions Remove everything exept the last index of the sender string, this only leaves the desired number
        private void btn1_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            addnumber(sender.ToString().Remove(0, sender.ToString().Length - 1));
        }
        // sets the operator to +, and stores lblAnswer.Text in tall1, then clears lblAnswer.Text
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (lblAnswer.Text != "")
            {
                op = "+";
                tall1 = float.Parse(lblAnswer.Text);
                lblAnswer.Text = "";
            }
        }
        // sets the operator to -, and stores lblAnswer.Text in tall1, then clears lblAnswer.Text
        private void btnSubtract_Click(object sender, EventArgs e)
        {
            if (lblAnswer.Text != "") 
            { 
            op = "-";
            tall1 = float.Parse(lblAnswer.Text);
            lblAnswer.Text = "";
            }
        }
        // sets the operator to *, and stores lblAnswer.Text in tall1, then clears lblAnswer.Text
        private void btnMultiply_Click(object sender, EventArgs e)
        {
            if (lblAnswer.Text != "")
            {
                op = "*";
                tall1 = float.Parse(lblAnswer.Text);
                lblAnswer.Text = "";
            }
        }
        // sets the operator to /, and stores lblAnswer.Text in tall1, then clears lblAnswer.Text

        private void btnDivide_Click(object sender, EventArgs e)
        {
            if (lblAnswer.Text != "")
            {
                op = "/";
                tall1 = float.Parse(lblAnswer.Text);
                lblAnswer.Text = "";
            }
        }
        // deletes the last index of lblAnswer.Text
        private void btnLeftArrow_Click(object sender, EventArgs e)
        {
            if (lblAnswer.Text != "")
            {
                lblAnswer.Text = lblAnswer.Text.Remove(lblAnswer.Text.Length - 1);
            }
        }
        // uses tall1 as the first operand, op as the operator, and lblAnswer.Text as the second operator. Then outputs the answer to lblAnswer.Text
        private void btnEqual_Click(object sender, EventArgs e)
        {
            if (tall1 != 0 && lblAnswer.Text != "")
            {
                float answer = tall1 + float.Parse(lblAnswer.Text);
                if (op == "-") { answer = tall1 - float.Parse(lblAnswer.Text); }
                else if (op == "*") { answer = tall1 * float.Parse(lblAnswer.Text); }
                else if (op == "/") { answer = tall1 / float.Parse(lblAnswer.Text); }

                lblAnswer.Text = answer.ToString();
                tall1 = 0;
            }
        }
        // adds a comma to the string, but only if there isn't already one
        private void btnComma_Click(object sender, EventArgs e)
        {
            if (lblAnswer.Text.IndexOf(".") == -1) {
                lblAnswer.Text = lblAnswer.Text + ".";
            }
        }
        // divides lblAnswer.Text by 100
        private void btnPercent_Click(object sender, EventArgs e)
        {
            if (lblAnswer.Text != "") { 
            float x = float.Parse(lblAnswer.Text);
            float y = x / 100;
                lblAnswer.Text = y.ToString();
            }
        }

        // should put the focus on btnEqual when the form loads
        private void kalkulator_Load(object sender, EventArgs e)
        {
            btnEqual.Focus();
        }

        // keyboard detection
        private void btnEqual_KeyDown(object sender, KeyEventArgs e)
        {

            // sets the operator to +, and stores lblAnswer.Text in tall1, then clears lblAnswer.Text, when you press + on the numpad
            if (e.KeyCode == Keys.Add)
            {
                if (lblAnswer.Text != "")
                {
                    op = "+";
                    tall1 = float.Parse(lblAnswer.Text);
                    lblAnswer.Text = "";
                }
            }
            // sets the operator to -, and stores lblAnswer.Text in tall1, then clears lblAnswer.Text, when you press - on the numpad
            else if (e.KeyCode == Keys.Subtract)
            {
                if (lblAnswer.Text != "")
                {
                    op = "-";
                    tall1 = float.Parse(lblAnswer.Text);
                    lblAnswer.Text = "";
                }
            }
            // sets the operator to *, and stores lblAnswer.Text in tall1, then clears lblAnswer.Text, when you press * on the numpad
            else if (e.KeyCode == Keys.Multiply)
            {
                if (lblAnswer.Text != "")
                {
                    op = "*";
                    tall1 = float.Parse(lblAnswer.Text);
                    lblAnswer.Text = "";
                }
            }
            // sets the operator to /, and stores lblAnswer.Text in tall1, then clears lblAnswer.Text, when you press / on the numpad
            else if (e.KeyCode == Keys.Divide)
            {
                if (lblAnswer.Text != "")
                {
                    op = "/";
                    tall1 = float.Parse(lblAnswer.Text);
                    lblAnswer.Text = "";
                }
            }
            // removes the last index of lblAnswer.Text when you press Backspace
            else if (e.KeyCode == Keys.Back)
            {
                if (lblAnswer.Text != "")
                {
                    lblAnswer.Text = lblAnswer.Text.Remove(lblAnswer.Text.Length - 1);
                }
            }
            // clears lblAnswer.Text and tall1 when you press C
            else if (e.KeyCode == Keys.C)
            {
                lblAnswer.Text = "";
                tall1 = 0;
            }
            // the numbers on the top row
            else if (e.KeyCode == Keys.D0) { addnumber("0"); }
            else if (e.KeyCode == Keys.D1) { addnumber("1"); }
            else if (e.KeyCode == Keys.D2) { addnumber("2"); }
            else if (e.KeyCode == Keys.D3) { addnumber("3"); }
            else if (e.KeyCode == Keys.D4) { addnumber("4"); }
            else if (e.KeyCode == Keys.D5) { addnumber("5"); }
            else if (e.KeyCode == Keys.D6) { addnumber("6"); }
            else if (e.KeyCode == Keys.D7) { addnumber("7"); }
            else if (e.KeyCode == Keys.D8) { addnumber("8"); }
            else if (e.KeyCode == Keys.D9) { addnumber("9"); }
            // the numbers on the numpad
            else if (e.KeyCode == Keys.NumPad0) { addnumber("0"); }
            else if (e.KeyCode == Keys.NumPad1) { addnumber("1"); }
            else if (e.KeyCode == Keys.NumPad2) { addnumber("2"); }
            else if (e.KeyCode == Keys.NumPad3) { addnumber("3"); }
            else if (e.KeyCode == Keys.NumPad4) { addnumber("4"); }
            else if (e.KeyCode == Keys.NumPad5) { addnumber("5"); }
            else if (e.KeyCode == Keys.NumPad6) { addnumber("6"); }
            else if (e.KeyCode == Keys.NumPad7) { addnumber("7"); }
            else if (e.KeyCode == Keys.NumPad8) { addnumber("8"); }
            else if (e.KeyCode == Keys.NumPad9) { addnumber("9"); }

        }
        // when the form loads it automaticly puts the focus on btnPercent, this reroutes it to btnEqual
        private void btnPercent_Enter(object sender, EventArgs e)
        {
            btnEqual.Focus();
        }
        // focus cannot leave btnEqual, because it would break keyboard detection
        private void btnEqual_Leave(object sender, EventArgs e)
        {
            btnEqual.Focus();
        }
    }
}
